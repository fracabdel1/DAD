package actuadores;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SistemaDeRiego {
	@JsonCreator
	public SistemaDeRiego(
			@JsonProperty("idSistema_de_riego")int idSistema_de_riego,
			@JsonProperty("timestamp")long timestamp,
			@JsonProperty("name")String name, 
			@JsonProperty("sector")String sector,
			@JsonProperty("activo")Integer activo,
			@JsonProperty("guardiaAgricola_idGuardiaAgricola")int guardiaAgricola_idGuardiaAgricola) {
		super();
		this.idSistema_de_riego = idSistema_de_riego;
		this.timestamp = timestamp;
		this.name = name;
		this.sector = sector;
		this.activo = activo;
		GuardiaAgricola_idGuardiaAgricola = guardiaAgricola_idGuardiaAgricola;
	}
	private int idSistema_de_riego;
	private long timestamp;
	private String name;
	private String sector;
	private Integer activo;
	private int GuardiaAgricola_idGuardiaAgricola;
	public int getIdSistema_de_riego() {
		return idSistema_de_riego;
	}
	public void setIdSistema_de_riego(int idSistema_de_riego) {
		this.idSistema_de_riego = idSistema_de_riego;
	}
	public long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public Integer getActivo() {
		return activo;
	}
	public void setActivo(Integer activo) {
		this.activo = activo;
	}
	public int getGuardiaAgricola_idGuardiaAgricola() {
		return GuardiaAgricola_idGuardiaAgricola;
	}
	public void setGuardiaAgricola_idGuardiaAgricola(int guardiaAgricola_idGuardiaAgricola) {
		GuardiaAgricola_idGuardiaAgricola = guardiaAgricola_idGuardiaAgricola;
	}
}
