package actuadores;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Altavoz {

	private int idaltavoz;
	private int activo;
	private long timestamp;
	private int GuardiaAgricola_idGuardiaAgricola;
	
	@JsonCreator
	public Altavoz(
			@JsonProperty("idaltavoz")int idaltavoz,
			@JsonProperty("activo")int activo,
			@JsonProperty("timestamp")long timestamp,
			@JsonProperty("GuardiaAgricola_idGuardiaAgricola")int GuardiaAgricola_idGuardiaAgricola) {
		super();
		this.idaltavoz=idaltavoz;
		this.activo=activo;
		this.timestamp=timestamp;
		this.GuardiaAgricola_idGuardiaAgricola=GuardiaAgricola_idGuardiaAgricola;
	}

	public int getIdaltavoz() {
		return idaltavoz;
	}

	public void setIdaltavoz(int idaltavoz) {
		this.idaltavoz = idaltavoz;
	}

	public int getActivo() {
		return activo;
	}

	public void setActivo(int activo) {
		this.activo = activo;
	}

	
	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public int getGuardiaAgricola_idGuardiaAgricola() {
		return GuardiaAgricola_idGuardiaAgricola;
	}

	public void setGuardiaAgricola_idGuardiaAgricola(int guardiaAgricola_idGuardiaAgricola) {
		GuardiaAgricola_idGuardiaAgricola = guardiaAgricola_idGuardiaAgricola;
	}
}
