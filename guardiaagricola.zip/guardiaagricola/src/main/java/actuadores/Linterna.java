package actuadores;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Linterna {
	private int idlinterna;
	private int activo;
	private long timestamp;
	private int GuardiaAgricola_idGuardiaAgricola;
	
	@JsonCreator
	public Linterna(
			@JsonProperty("idlinterna")int idlinterna,
			@JsonProperty("activo")int activo,
			@JsonProperty("timestamp")long timestamp,
			@JsonProperty("GuardiaAgricola_idGuardiaAgricola")int GuardiaAgricola_idGuardiaAgricola) {
		super();
		this.idlinterna=idlinterna;
		this.activo=activo;
		this.timestamp=timestamp;
		this.GuardiaAgricola_idGuardiaAgricola=GuardiaAgricola_idGuardiaAgricola;
	}

	public int getIdLinterna() {
		return idlinterna;
	}

	public void setIdLinterna(int idLinterna) {
		this.idlinterna = idLinterna;
	}

	public int getActivo() {
		return activo;
	}

	public void setActivo(int activo) {
		this.activo = activo;
	}

	
	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public int getGuardiaAgricola_idGuardiaAgricola() {
		return GuardiaAgricola_idGuardiaAgricola;
	}

	public void setGuardiaAgricola_idGuardiaAgricola(int guardiaAgricola_idGuardiaAgricola) {
		GuardiaAgricola_idGuardiaAgricola = guardiaAgricola_idGuardiaAgricola;
	}
}
