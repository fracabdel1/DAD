package placa;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Placa {
	
	@JsonCreator
	public Placa(
			@JsonProperty("idGuardiaAgricola")int idGuardiaAgricola, 
			@JsonProperty("modelo")String modelo,
			@JsonProperty("cultivo")String cultivo,
			@JsonProperty("name")String name, 
			@JsonProperty("timestamp")long timestamp,
			@JsonProperty("ip")String ip) {
		super();
		this.idGuardiaAgricola = idGuardiaAgricola;
		this.modelo = modelo;
		this.cultivo = cultivo;
		this.name = name;
		this.timestamp = timestamp;
		this.ip = ip;
	}
	
	private int idGuardiaAgricola;
	private String modelo;
	private String cultivo;
	private String name;
	private long timestamp;
	private String ip;
	
	public int getIdGuardiaAgricola() {
		return idGuardiaAgricola;
	}
	public void setIdGuardiaAgricola(int idGuardiaAgricola) {
		this.idGuardiaAgricola = idGuardiaAgricola;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getCultivo() {
		return cultivo;
	}
	public void setCultivo(String cultivo) {
		this.cultivo = cultivo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
}
