package basedeDatos;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;


public class Verticle extends AbstractVerticle{
	@Override
	public void start(Future<Void> startFuture) {
		vertx.deployVerticle(ApiRest.class.getName());
	}
}
