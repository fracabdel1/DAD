package basedeDatos;

import com.fasterxml.jackson.annotation.JsonProperty;

import actuadores.Altavoz;
import actuadores.Linterna;
import actuadores.SistemaDeRiego;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;
import io.vertx.mysqlclient.MySQLClient;
import io.vertx.mysqlclient.MySQLConnectOptions;
import io.vertx.mysqlclient.MySQLPool;
import io.vertx.sqlclient.PoolOptions;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.RowSet;
import io.vertx.sqlclient.Tuple;
import placa.Placa;
import sensores.Humidity;
import sensores.Intruder;
import sensores.Luminosity;
import sensores.Temperature;
import usuario.Usuario;

public class ApiRest extends AbstractVerticle {
	private MySQLPool mySQLPool;
	@Override
	public void start(Promise<Void> startPromise) {
		MySQLConnectOptions mySQLConnectOptions =new MySQLConnectOptions().setPort(3306).setHost("localhost")
				.setDatabase("guardiaagricola").setUser("root").setPassword("root");
		PoolOptions poolOptions =new PoolOptions().setMaxSize(5);
		mySQLPool=MySQLPool.pool(vertx,mySQLConnectOptions,poolOptions);
		
		Router router =Router.router(vertx);
		router.route().handler(BodyHandler.create());
		
		vertx.createHttpServer().requestHandler(router::handle).listen(8081,result->{
			if(result.succeeded()) {
				startPromise.complete();
			}else {
				startPromise.fail(result.cause());
			}
		});
		
		//============================URLs de Sensores============================//
		
		
		//============================URLs de Temperature============================//
		router.route("/api/temperature*").handler(BodyHandler.create());
		router.get("/api/temperature/values/:guardiaAgricola_idGuardiaAgricola").handler(this::getValueBytemperature);
		router.get("/api/temperature/values/:guardiaAgricola_idGuardiaAgricola/:timestamp").handler(this::getValueBytemperatureAndTimestamp);
		router.put("/api/temperature/values").handler(this::putValueFortemperature);
		router.post("/api/temperature/values/:idtemperatura").handler(this::postValueFortemperature);
		router.delete("/api/temperature/values/:idtemperatura").handler(this::deleteValueFortemperature);
		//============================URLs de Intruder============================//
		router.route("/api/intruder*").handler(BodyHandler.create());
		router.get("/api/intruder/values/:guardiaAgricola_idGuardiaAgricola").handler(this::getValueByIntruder);
		router.get("/api/intruder/values/:guardiaAgricola_idGuardiaAgricola/:timestamp").handler(this::getValueByIntruderAndTimestamp);
		router.put("/api/intruder/values").handler(this::putValueForIntruder);
		router.post("/api/intruder/values/:idmovimiento").handler(this::postValueForintruder);
		router.delete("/api/intruder/values/:idmovimiento").handler(this::deleteValueForintruder);
		//============================URLs de Luminosity============================//
		router.route("/api/luminosity*").handler(BodyHandler.create());
		router.get("/api/luminosity/values/:guardiaAgricola_idGuardiaAgricola").handler(this::getValueByLuminosity);
		router.get("/api/luminosity/values/:guardiaAgricola_idGuardiaAgricola/:timestamp").handler(this::getValueByLuminosityAndTimestamp);
		router.put("/api/luminosity/values").handler(this::putValueForLuminosity);
		router.post("/api/luminosity/values/:idluminosidad").handler(this::postValueForluminosity);
		router.delete("/api/luminosity/values/:idluminosidad").handler(this::deleteValueForluminosity);
		//============================URLs de Humidity============================//
		router.route("/api/humidity*").handler(BodyHandler.create());
		router.get("/api/humidity/values/:guardiaAgricola_idGuardiaAgricola").handler(this::getValueByHumidity);
		router.get("/api/humidity/values/:guardiaAgricola_idGuardiaAgricola/:timestamp").handler(this::getValueByHumidityAndTimestamp);
		router.put("/api/humidity/values").handler(this::putValueForHumidity);
		router.post("/api/humidity/values/:idhumedad").handler(this::postValueForhumidity);
		router.delete("/api/humidity/values/:idhumedad").handler(this::deleteValueForhumidity);
		//========================================================//
		
		//============================URLs de Placa============================//
		router.route("/api/placa*").handler(BodyHandler.create());
		router.get("/api/placa/values/:idGuardiaAgricola").handler(this::getValuesForPlaca);
		router.put("/api/placa/values").handler(this::putOnePlaca);
		router.post("/api/placa/values/:idGuardiaAgricola").handler(this::postValueForplaca);
		router.delete("/api/placa/values/:idGuardiaAgricola").handler(this::deleteOnePlaca);
		//========================================================//
	
		//============================URLs de Actuadores============================//
		
		//============================URLs de Altavoz============================//
		router.route("/api/altavoz*").handler(BodyHandler.create());
		router.get("/api/altavoz/values/:GuardiaAgricola_idGuardiaAgricola").handler(this::getValueAltavoz);
		router.put("/api/altavoz/values").handler(this::putValueAltavoz);
		router.delete("/api/altavoz/values/:timestamp").handler(this::deleteValueAltavoz);
		//============================URLs de Linterna============================//
		router.route("/api/linterna*").handler(BodyHandler.create());
		router.get("/api/linterna/values/:GuardiaAgricola_idGuardiaAgricola").handler(this::getValueLinterna);
		router.put("/api/linterna/values").handler(this::putValueLinterna);
		router.delete("/api/linterna/values/:timestamp").handler(this::deleteValueLinterna);
		//============================URLs de Sistema De Riego============================//
		router.route("/api/sistema_de_riego*").handler(BodyHandler.create());
		router.get("/api/sistema_de_riego/values/:idSistema_de_riego").handler(this::getValueBysistemaderiego);
		router.get("/api/sistema_de_riego/values/:idSistema_de_riego/:timestamp").handler(this::getValueBysistemaderiegoAndTimestamp);
		router.put("/api/sistema_de_riego/values").handler(this::putValueForsistemaderiego);
		router.post("/api/sistema_de_riego/values/:idSistema_de_riego").handler(this::postValueForsistemaderiego);
		router.delete("/api/sistema_de_riego/values/:idSistema_de_riego").handler(this::deleteValueForsistemaderiego);
		//========================================================//
		
		//============================URLs de Usuario============================//
		router.route("/api/usuario*").handler(BodyHandler.create());
		router.get("/api/usuario/values/:idUsuario").handler(this::getValuesForUsuario);
		router.put("/api/usuario/values").handler(this::putOneUsuario);
		router.post("/api/usuario/values/:idUsuario").handler(this::postValueForUsuario);
		router.delete("/api/usuario/values/:idUsuario").handler(this::deleteOneUsuario);
		}
	
	
		//============================M�todos de Temperature============================//
		private void postValueFortemperature(RoutingContext routingContext) {

        int id = Integer.parseInt(routingContext.request().getParam("idtemperatura"));
        Temperature Temperature = Json.decodeValue(routingContext.getBodyAsString(), Temperature.class);
        Temperature.setId(id);
        mySQLPool.query("UPDATE guardiaagricola.temperatura SET value = '"+Temperature.getValue()+
                "', timestamp = '"+Temperature.getTimestamp()+"', accuracy = '"+Temperature.getAccuracy()+
                "', GuardiaAgricola_idGuardiaAgricola = '"+Temperature.getGuardiaAgricola_idGuardiaAgricola()+"' WHERE (idtemperatura = '"
                +id+"')",
                handler -> {
                    if (handler.succeeded()) {
                        System.out.println(handler.result().rowCount());
                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
                                .end(JsonObject.mapFrom(Temperature).encodePrettily());
                    } else {
                        System.out.println(handler.cause().toString());
                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
                    }
                });
		}
		private void deleteValueFortemperature(RoutingContext routingContext) {
			int id = Integer.parseInt(routingContext.request().getParam("idtemperatura"));
			mySQLPool.query("DELETE FROM guardiaagricola.temperatura  WHERE (idtemperatura = "+id+");",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end("Eliminado con �xito un elemento de la tabla");
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
		}
		private void putValueFortemperature(RoutingContext routingContext) {
			Temperature Temperature = Json.decodeValue(routingContext.getBodyAsString(), Temperature.class);
			mySQLPool.preparedQuery(
					"INSERT INTO guardiaagricola.temperatura (value, timestamp, accuracy, GuardiaAgricola_idGuardiaAgricola) VALUES (?,?,?,?)",
					Tuple.of(Temperature.getValue(), Temperature.getTimestamp(),
							Temperature.getAccuracy(), Temperature.getGuardiaAgricola_idGuardiaAgricola()),
					handler -> {
						if (handler.succeeded()) {
							System.out.println(handler.result().rowCount());
							
							long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
							Temperature.setId((int) id);
							
							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(JsonObject.mapFrom(Temperature).encodePrettily());
						} else {
							System.out.println(handler.cause().toString());
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
						}
					});
		}
		private void getValueBytemperatureAndTimestamp(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.temperatura WHERE timestamp > "
					+ routingContext.request().getParam("timestamp") + " AND guardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("guardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Temperature(row.getInteger("idtemperatura"),
										 row.getFloat("value"), row.getInteger("accuracy"),
										row.getLong("timestamp"),row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void getValueBytemperature(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.temperatura WHERE guardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("guardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Temperature(row.getInteger("idtemperatura"),
										 row.getFloat("value"), row.getInteger("accuracy"),
										row.getLong("timestamp"),row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		//============================M�todos de Humidity============================//
		private void postValueForhumidity(RoutingContext routingContext) {
	        int id = Integer.parseInt(routingContext.request().getParam("idhumedad"));
	        Humidity Humidity = Json.decodeValue(routingContext.getBodyAsString(), Humidity.class);
	        Humidity.setId(id);
	        mySQLPool.query("UPDATE guardiaagricola.humedad SET value = '"+Humidity.getValue()+
	                "', timestamp = '"+Humidity.getTimestamp()+"', accuracy = '"+Humidity.getAccuracy()+
	                "', GuardiaAgricola_idGuardiaAgricola = '"+Humidity.getGuardiaAgricola_idGuardiaAgricola()+"' WHERE (idhumedad = '"
	                +id+"')",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end(JsonObject.mapFrom(Humidity).encodePrettily());
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
			}
		private void putValueForHumidity(RoutingContext routingContext) {
			Humidity Humidity = Json.decodeValue(routingContext.getBodyAsString(), Humidity.class);
			mySQLPool.preparedQuery(
					"INSERT INTO humedad (value, timestamp,accuracy,GuardiaAgricola_idGuardiaAgricola) VALUES (?,?,?,?)",
					Tuple.of(Humidity.getValue(), Humidity.getAccuracy(),
							Humidity.getTimestamp(),Humidity.getGuardiaAgricola_idGuardiaAgricola()),
					handler -> {
						if (handler.succeeded()) {
							System.out.println(handler.result().rowCount());
							
							long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
							Humidity.setId((int) id);
							
							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(JsonObject.mapFrom(Humidity).encodePrettily());
						} else {
							System.out.println(handler.cause().toString());
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
						}
					});
		}
		private void deleteValueForhumidity(RoutingContext routingContext) {
			int id = Integer.parseInt(routingContext.request().getParam("idhumedad"));
			mySQLPool.query("DELETE FROM guardiaagricola.humedad  WHERE (idhumedad = "+id+");",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end("Eliminado con �xito un elemento de la tabla");
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
		}
		private void getValueByHumidityAndTimestamp(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.humedad WHERE timestamp > "
					+ routingContext.request().getParam("timestamp") + " AND guardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("guardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Humidity(row.getInteger("idhumedad"),
										row.getFloat("value"), row.getInteger("accuracy"),
										row.getLong("timestamp"),row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void getValueByHumidity(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.humedad WHERE guardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("guardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Humidity(row.getInteger("idhumedad"),
										 row.getFloat("value"), row.getInteger("accuracy"),
										row.getLong("timestamp"),row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		//============================M�todos de Intruder============================//
		private void postValueForintruder(RoutingContext routingContext) {
	        int id = Integer.parseInt(routingContext.request().getParam("idmovimiento"));
	        Intruder Intruder = Json.decodeValue(routingContext.getBodyAsString(), Intruder.class);
	        Intruder.setId(id);
	        mySQLPool.query("UPDATE guardiaagricola.movimiento SET value = "+Intruder.getValue()+
	                ", timestamp = "+Intruder.getTimestamp()+", accuracy = "+Intruder.getAccuracy()+
	                ", GuardiaAgricola_idGuardiaAgricola = "+Intruder.getGuardiaAgricola_idGuardiaAgricola()+" WHERE (idmovimiento = "
	                +id+")",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end(JsonObject.mapFrom(Intruder).encodePrettily());
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
			}
		private void putValueForIntruder(RoutingContext routingContext) {
			Intruder intruder = Json.decodeValue(routingContext.getBodyAsString(), Intruder.class);
			mySQLPool.preparedQuery(
					"INSERT INTO guardiaagricola.movimiento (value, timestamp,accuracy,GuardiaAgricola_idGuardiaAgricola) VALUES (?,?,?,?)",
					Tuple.of(intruder.getValue(),intruder.getTimestamp(),
							intruder.getAccuracy(),intruder.getGuardiaAgricola_idGuardiaAgricola()),
					handler -> {
						if (handler.succeeded()) {
							System.out.println(handler.result().rowCount());
							
							long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
							intruder.setId((int) id);
							
							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(JsonObject.mapFrom(intruder).encodePrettily());
						} else {
							System.out.println(handler.cause().toString());
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
						}
					});
		}
		private void getValueByIntruderAndTimestamp(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.movimiento WHERE timestamp > "
					+ routingContext.request().getParam("timestamp") + " AND guardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("guardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Intruder(row.getInteger("idmovimiento"),
										 row.getInteger("value"), row.getInteger("accuracy"),
										row.getLong("timestamp"),row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void getValueByIntruder(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.movimiento WHERE guardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("guardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Intruder(row.getInteger("idmovimiento"),
										 row.getInteger("value"), row.getInteger("accuracy"),
										row.getLong("timestamp"),row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void deleteValueForintruder(RoutingContext routingContext) {
			int id = Integer.parseInt(routingContext.request().getParam("idmovimiento"));
			mySQLPool.query("DELETE FROM guardiaagricola.movimiento  WHERE (idmovimiento = "+id+");",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end("Eliminado con �xito un elemento de la tabla");
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
		}
		//============================M�todos de Luminosity============================//
		private void postValueForluminosity(RoutingContext routingContext) {
	        int id = Integer.parseInt(routingContext.request().getParam("idluminosidad"));
	        Luminosity Luminosity = Json.decodeValue(routingContext.getBodyAsString(), Luminosity.class);
	        Luminosity.setId(id);
	        mySQLPool.query("UPDATE guardiaagricola.luminosidad SET value = '"+Luminosity.getValue()+
	                "', timestamp = '"+Luminosity.getTimestamp()+"', accuracy = '"+Luminosity.getAccuracy()+
	                "', GuardiaAgricola_idGuardiaAgricola = '"+Luminosity.getGuardiaAgricola_idGuardiaAgricola()+"' WHERE (idluminosidad = '"
	                +id+"')",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end(JsonObject.mapFrom(Luminosity).encodePrettily());
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
			}
		private void putValueForLuminosity(RoutingContext routingContext) {
			Luminosity Luminosity = Json.decodeValue(routingContext.getBodyAsString(), Luminosity.class);
			mySQLPool.preparedQuery(
					"INSERT INTO luminosidad (value, accuracy, timestamp,GuardiaAgricola_idGuardiaAgricola) VALUES (?,?,?,?)",
					Tuple.of(Luminosity.getValue(), Luminosity.getAccuracy(),
							Luminosity.getTimestamp(),Luminosity.getGuardiaAgricola_idGuardiaAgricola()),
					handler -> {
						if (handler.succeeded()) {
							System.out.println(handler.result().rowCount());
							
							long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
							Luminosity.setId((int) id);
							
							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(JsonObject.mapFrom(Luminosity).encodePrettily());
						} else {
							System.out.println(handler.cause().toString());
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
						}
					});
		}
		private void getValueByLuminosityAndTimestamp(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.luminosidad WHERE timestamp > "
					+ routingContext.request().getParam("timestamp") + " AND guardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("guardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Luminosity(row.getInteger("idluminosidad"),
										 row.getFloat("value"), row.getInteger("accuracy"),
										row.getLong("timestamp"),row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void getValueByLuminosity(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.luminosidad WHERE guardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("guardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Luminosity(row.getInteger("idluminosidad"),
										 row.getFloat("value"), row.getInteger("accuracy"),
										row.getLong("timestamp"),row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void deleteValueForluminosity(RoutingContext routingContext) {
			int id = Integer.parseInt(routingContext.request().getParam("idluminosidad"));
			mySQLPool.query("DELETE FROM guardiaagricola.luminosidad  WHERE (idluminosidad = "+id+");",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end("Eliminado con �xito un elemento de la tabla");
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
		}
		//============================M�todos de Placa============================//
		private void postValueForplaca(RoutingContext routingContext) {
	        int id = Integer.parseInt(routingContext.request().getParam("idGuardiaAgricola"));
	        Placa Placa = Json.decodeValue(routingContext.getBodyAsString(), Placa.class);
	        Placa.setIdGuardiaAgricola(id);
	        mySQLPool.query("UPDATE guardiaagricola.guardiaagricola SET cultivo = '"+Placa.getCultivo()+
	                "', name = '"+Placa.getName()+"', ip = '"+Placa.getIp()+
	                "' WHERE (idGuardiaAgricola = '"
	                +id+"')",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end(JsonObject.mapFrom(Placa).encodePrettily());
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
			}
		private void getValuesForPlaca(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.guardiaagricola WHERE idGuardiaAgricola = "
					+ routingContext.request().getParam("idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Placa(
										row.getInteger("idGuardiaAgricola"),
										row.getString("modelo"),
										row.getString("cultivo"),
										row.getString("name"),
										row.getLong("timestamp"),
										row.getString("ip"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void deleteOnePlaca(RoutingContext routingContext) {
			int id = Integer.parseInt(routingContext.request().getParam("idGuardiaAgricola"));
			mySQLPool.query("DELETE FROM guardiaagricola.guardiaagricola  WHERE (idGuardiaAgricola = "+id+");",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end("Eliminado con �xito un elemento de la tabla");
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
		}
		private void putOnePlaca(RoutingContext routingContext) {
		//	int idUsuario=Integer.parseInt(routingContext.request().getParam("idUsuario"));
			Placa Placa = Json.decodeValue(routingContext.getBodyAsString(), Placa.class);
			mySQLPool.preparedQuery(
					"INSERT INTO guardiaagricola.guardiaagricola (modelo,cultivo,name,timestamp,ip) VALUES (?,?,?,?,?);",
							//+ "INSERT INTO guardiaagricola.usuario_has_guardiaagricola VALUES ("+idUsuario+", "+Placa.getIdGuardiaAgricola()+");",
					Tuple.of(Placa.getModelo(), Placa.getCultivo(),
							Placa.getName(),Placa.getTimestamp(),Placa.getIp()),
					handler -> {
						if (handler.succeeded()) {
							System.out.println(handler.result().rowCount());
							
							long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
							Placa.setIdGuardiaAgricola((int) id);
							
							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(JsonObject.mapFrom(Placa).encodePrettily()+Placa.getIdGuardiaAgricola());
						} else {
							System.out.println(handler.cause().toString());
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
						}
					});
		}
		//============================M�todos de Altavoz============================//
		private void getValueAltavoz(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.altavoz WHERE GuardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("GuardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Altavoz(row.getInteger("idaltavoz"),
								row.getInteger("activo"),
								row.getLong("timestamp"), 
								row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
			
		}
		private void putValueAltavoz(RoutingContext routingContext) {

			Altavoz altavoz = Json.decodeValue(routingContext.getBodyAsString(), Altavoz.class);
			mySQLPool.preparedQuery(
					"INSERT INTO altavoz (activo, timestamp,GuardiaAgricola_idGuardiaAgricola) VALUES (?,?,?)",
					Tuple.of(altavoz.getActivo(), altavoz.getTimestamp(),
							altavoz.getGuardiaAgricola_idGuardiaAgricola()),
					handler -> {
						if (handler.succeeded()) {
							System.out.println(handler.result().rowCount());
							
							long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
							altavoz.setIdaltavoz((int) id);
							
							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(JsonObject.mapFrom(altavoz).encodePrettily());
						} else {
							System.out.println(handler.cause().toString());
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
						}
					});
		}
		private void deleteValueAltavoz(RoutingContext routingContext) {
			long timestamp  = Long.parseLong(routingContext.request().getParam("timestamp"));
           	 mySQLPool.query("DELETE FROM guardiaagricola.altavoz  WHERE (timestamp > "+timestamp+");",
                    handler -> {
                        if (handler.succeeded()) {
                            System.out.println(handler.result().rowCount());
                            routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
                                    .end("Eliminado con �xito un elemento de la tabla");
                        } else {
                            System.out.println(handler.cause().toString());
                            routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
                                    .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
                        }
                    });
		}
		//============================M�todos de Linterna============================//
		private void getValueLinterna(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.linterna WHERE GuardiaAgricola_idGuardiaAgricola = "
					+ routingContext.request().getParam("GuardiaAgricola_idGuardiaAgricola"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new Linterna(row.getInteger("idlinterna"),
								row.getInteger("activo"),
								row.getLong("timestamp"), 
								row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
			
		}
		private void putValueLinterna(RoutingContext routingContext) {

			Linterna linterna = Json.decodeValue(routingContext.getBodyAsString(), Linterna.class);
			mySQLPool.preparedQuery(
					"INSERT INTO linterna (activo, timestamp,GuardiaAgricola_idGuardiaAgricola) VALUES (?,?,?)",
					Tuple.of(linterna.getActivo(), linterna.getTimestamp(),
							linterna.getGuardiaAgricola_idGuardiaAgricola()),
					handler -> {
						if (handler.succeeded()) {
							System.out.println(handler.result().rowCount());
							
							long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
							linterna.setIdLinterna((int) id);
							
							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(JsonObject.mapFrom(linterna).encodePrettily());
						} else {
							System.out.println(handler.cause().toString());
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
						}
					});
		}
		private void deleteValueLinterna(RoutingContext routingContext) {
			long timestamp  = Long.parseLong(routingContext.request().getParam("timestamp"));
            mySQLPool.query("DELETE FROM guardiaagricola.linterna  WHERE (timestamp > "+timestamp+");",
                    handler -> {
                        if (handler.succeeded()) {
                            System.out.println(handler.result().rowCount());
                            routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
                                    .end("Eliminado con �xito un elemento de la tabla");
                        } else {
                            System.out.println(handler.cause().toString());
                            routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
                                    .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
                        }
                    });
		}
		//============================M�todos de Sistema De Riego============================//
		private void deleteValueForsistemaderiego(RoutingContext routingContext) {
			int id = Integer.parseInt(routingContext.request().getParam("idSistema_de_riego"));
			mySQLPool.query("DELETE FROM guardiaagricola.sistema_de_riego  WHERE (idSistema_de_riego = "+id+");",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end("Eliminado con �xito un elemento de la tabla");
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
		}
		private void getValueBysistemaderiego(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.sistema_de_riego WHERE idSistema_de_riego = "
					+ routingContext.request().getParam("idSistema_de_riego"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new SistemaDeRiego(row.getInteger("idSistema_de_riego"),
										 row.getLong("timestamp"), row.getString("name"),
										row.getString("sector"),row.getInteger("activo"),
										row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void getValueBysistemaderiegoAndTimestamp(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.sistema_de_riego WHERE timestamp > "
					+ routingContext.request().getParam("timestamp") + " AND idSistema_de_riego = "
					+ routingContext.request().getParam("idSistema_de_riego"), res -> {
						if (res.succeeded()) {
							RowSet<Row> resultSet = res.result();
							System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
							JsonArray result = new JsonArray();
							for (Row row : resultSet) {
								result.add(JsonObject.mapFrom(new SistemaDeRiego(row.getInteger("idSistema_de_riego"),
										 row.getLong("timestamp"), row.getString("name"),
										row.getString("sector"),row.getInteger("activo"),
										row.getInteger("GuardiaAgricola_idGuardiaAgricola"))));
							}

							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(result.encodePrettily());
						} else {
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
						}
					});
		}
		private void putValueForsistemaderiego(RoutingContext routingContext) {
			SistemaDeRiego Sistemaderiego = Json.decodeValue(routingContext.getBodyAsString(), SistemaDeRiego.class);
			mySQLPool.preparedQuery(
					"INSERT INTO guardiaagricola.sistema_de_riego (timestamp, name, sector, activo, GuardiaAgricola_idGuardiaAgricola) VALUES (?,?,?,?,?)",
					Tuple.of(Sistemaderiego.getTimestamp(),Sistemaderiego.getName(),Sistemaderiego.getSector(),
							Sistemaderiego.getActivo(), Sistemaderiego.getGuardiaAgricola_idGuardiaAgricola()),
					handler -> {
						if (handler.succeeded()) {
							System.out.println(handler.result().rowCount());
							
							long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
							Sistemaderiego.setIdSistema_de_riego((int) id);
							
							routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
									.end(JsonObject.mapFrom(Sistemaderiego).encodePrettily());
						} else {
							System.out.println(handler.cause().toString());
							routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
									.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
						}
					});
		}
		private void postValueForsistemaderiego(RoutingContext routingContext) {
	        int id = Integer.parseInt(routingContext.request().getParam("idSistema_de_riego"));
	        SistemaDeRiego SistemaDeRiego = Json.decodeValue(routingContext.getBodyAsString(), SistemaDeRiego.class);
	        SistemaDeRiego.setIdSistema_de_riego(id);
	        mySQLPool.query("UPDATE guardiaagricola.sistema_de_riego SET name = '"+SistemaDeRiego.getName()+
	                "', timestamp = '"+SistemaDeRiego.getTimestamp()+"', sector = '"+SistemaDeRiego.getSector()+ "', activo= "+SistemaDeRiego.getActivo()+
	                ", GuardiaAgricola_idGuardiaAgricola = '"+SistemaDeRiego.getGuardiaAgricola_idGuardiaAgricola()+"' WHERE (idSistema_de_riego = "
	                +id+")",
	                handler -> {
	                    if (handler.succeeded()) {
	                        System.out.println(handler.result().rowCount());
	                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
	                                .end(JsonObject.mapFrom(SistemaDeRiego).encodePrettily());
	                    } else {
	                        System.out.println(handler.cause().toString());
	                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
	                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
	                    }
	                });
			}

		//============================M�todos de Usuario============================//
		private void postValueForUsuario(RoutingContext routingContext) {
        	int id = Integer.parseInt(routingContext.request().getParam("idUsuario"));
        	Usuario Usuario = Json.decodeValue(routingContext.getBodyAsString(), Usuario.class);
        	Usuario.setIdUsuario(id);
       		mySQLPool.query("UPDATE guardiaagricola.usuario SET  name = '"+Usuario.getName()+"'"
       				+ ", dni = '"+Usuario.getDni()+"', username = '"+Usuario.getUsername()+"', telefono = '"+Usuario.getTelefono()+"', "
       				+ "direccion = '"+Usuario.getDireccion()+"', password = '"+Usuario.getPassword()+"' WHERE (idUsuario = "+id+");",
                handler -> {
                    if (handler.succeeded()) {
                        System.out.println(handler.result().rowCount());
                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
                                .end(JsonObject.mapFrom(Usuario).encodePrettily());
                    } else {
                        System.out.println(handler.cause().toString());
                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
                    }
                });
		}
		private void getValuesForUsuario(RoutingContext routingContext) {
			mySQLPool.query("SELECT * FROM guardiaagricola.usuario WHERE idUsuario = "
				+ routingContext.request().getParam("idUsuario"), res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new Usuario(
									row.getInteger("idUsuario"),
									 row.getString("name"),
									row.getString("dni") ,row.getString("username") ,
									row.getInteger("telefono") ,row.getString("direccion") ,
									row.getString("password"))));
						}

						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(result.encodePrettily());
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
	}
		private void deleteOneUsuario(RoutingContext routingContext) {
			int id = Integer.parseInt(routingContext.request().getParam("idUsuario"));
			mySQLPool.query("DELETE FROM guardiaagricola.usuario  WHERE (idUsuario = "+id+");",
                handler -> {
                    if (handler.succeeded()) {
                        System.out.println(handler.result().rowCount());
                        routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
                                .end("Eliminado con �xito un elemento de la tabla");
                    } else {
                        System.out.println(handler.cause().toString());
                        routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
                                .end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
                    }
                });
	}
		private void putOneUsuario(RoutingContext routingContext) {
			Usuario Usuario = Json.decodeValue(routingContext.getBodyAsString(), Usuario.class);
			mySQLPool.preparedQuery(
				"INSERT INTO guardiaagricola.usuario (name, dni, username, telefono, direccion, password)"
				+ " VALUES (?,?,?,?,?,?);",
				Tuple.of(Usuario.getName(),Usuario.getDni(),Usuario.getUsername(),
						Usuario.getTelefono(),Usuario.getDireccion(),Usuario.getPassword()),
				handler -> {
					if (handler.succeeded()) {
						System.out.println(handler.result().rowCount());
						
						long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
						Usuario.setIdUsuario((int) id);
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(Usuario).encodePrettily());
					} else {
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
					}
				});
	}
}
