package sensores;

import java.util.Calendar;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Intruder {
	private static final AtomicInteger COUNTER=new AtomicInteger();
	
	private int id;
	private int value;
	private long timestamp;
	private int accuracy;
	private int GuardiaAgricola_idGuardiaAgricola;
	
	@JsonCreator
	public Intruder(
			@JsonProperty("id")int id,
			@JsonProperty("value")int value,
			@JsonProperty("accuracy")int accuracy,
			@JsonProperty("timestamp")long timestamp,
			@JsonProperty("GuardiaAgricola_idGuardiaAgricola")int GuardiaAgricola_idGuardiaAgricola) {
		super();
		this.id=id;
		this.accuracy=accuracy;
		this.timestamp=timestamp;
		this.value=value;
		this.GuardiaAgricola_idGuardiaAgricola=GuardiaAgricola_idGuardiaAgricola;
	}
	public Intruder() {
		super();
		this.id=COUNTER.getAndIncrement();
		this.accuracy=0;
		this.timestamp=
				Calendar.getInstance().getTimeInMillis();
		
		this.value=0;
	}
	public int getId() {
		return id;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public int getAccuracy() {
		return accuracy;
	}
	public void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}
	public int getGuardiaAgricola_idGuardiaAgricola() {
		return GuardiaAgricola_idGuardiaAgricola;
	}
	public void setGuardiaAgricola_idGuardiaAgricola(int GuardiaAgricola_idGuardiaAgricola) {
		this.GuardiaAgricola_idGuardiaAgricola = GuardiaAgricola_idGuardiaAgricola;
	}
	public void setId(int id) {
		this.id = id;
	}
}
