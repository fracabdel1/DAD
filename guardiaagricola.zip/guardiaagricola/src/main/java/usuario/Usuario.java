package usuario;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Usuario {
	private int idUsuario;
	private String name;
	private String dni;
	private String username;
	private int telefono;
	private String direccion;
	private String password;

	@JsonCreator
	public Usuario(@JsonProperty("idUsuario") int idUsuario, @JsonProperty("name") String name,
			@JsonProperty("dni") String dni, @JsonProperty("username") String username,
			@JsonProperty("telefono") int telefono, @JsonProperty("direccion") String direccion,
			@JsonProperty("password") String password) {
		super();
		this.idUsuario = idUsuario;
		this.name = name;
		this.dni = dni;
		this.username = username;
		this.telefono = telefono;
		this.direccion = direccion;
		this.password = password;
	}

	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
