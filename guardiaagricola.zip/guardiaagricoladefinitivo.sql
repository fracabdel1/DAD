-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: guardiaagricola
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `altavoz`
--

DROP TABLE IF EXISTS `altavoz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `altavoz` (
  `idaltavoz` int NOT NULL AUTO_INCREMENT,
  `activo` bit(1) DEFAULT NULL,
  `timestamp` bigint NOT NULL,
  `GuardiaAgricola_idGuardiaAgricola` int NOT NULL,
  PRIMARY KEY (`idaltavoz`),
  KEY `fk_altavoz_GuardiaAgricola1_idx` (`GuardiaAgricola_idGuardiaAgricola`),
  CONSTRAINT `fk_altavoz_GuardiaAgricola1` FOREIGN KEY (`GuardiaAgricola_idGuardiaAgricola`) REFERENCES `guardiaagricola` (`idGuardiaAgricola`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `altavoz`
--

LOCK TABLES `altavoz` WRITE;
/*!40000 ALTER TABLE `altavoz` DISABLE KEYS */;
INSERT INTO `altavoz` VALUES (2,_binary '',0,2);
/*!40000 ALTER TABLE `altavoz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guardiaagricola`
--

DROP TABLE IF EXISTS `guardiaagricola`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guardiaagricola` (
  `idGuardiaAgricola` int NOT NULL AUTO_INCREMENT,
  `modelo` varchar(45) DEFAULT NULL,
  `cultivo` varchar(45) DEFAULT NULL,
  `name` varchar(45) NOT NULL,
  `timestamp` bigint NOT NULL,
  `ip` varchar(45) NOT NULL,
  PRIMARY KEY (`idGuardiaAgricola`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guardiaagricola`
--

LOCK TABLES `guardiaagricola` WRITE;
/*!40000 ALTER TABLE `guardiaagricola` DISABLE KEYS */;
INSERT INTO `guardiaagricola` VALUES (2,'placa','trigo','trigo',31094,'12');
/*!40000 ALTER TABLE `guardiaagricola` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `humedad`
--

DROP TABLE IF EXISTS `humedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `humedad` (
  `idhumedad` int NOT NULL AUTO_INCREMENT,
  `value` float DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `accuracy` int DEFAULT NULL,
  `GuardiaAgricola_idGuardiaAgricola` int NOT NULL,
  PRIMARY KEY (`idhumedad`),
  KEY `fk_humedad_GuardiaAgricola1_idx` (`GuardiaAgricola_idGuardiaAgricola`),
  CONSTRAINT `fk_humedad_GuardiaAgricola1` FOREIGN KEY (`GuardiaAgricola_idGuardiaAgricola`) REFERENCES `guardiaagricola` (`idGuardiaAgricola`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `humedad`
--

LOCK TABLES `humedad` WRITE;
/*!40000 ALTER TABLE `humedad` DISABLE KEYS */;
/*!40000 ALTER TABLE `humedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linterna`
--

DROP TABLE IF EXISTS `linterna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `linterna` (
  `idlinterna` int NOT NULL AUTO_INCREMENT,
  `activo` bit(1) DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `GuardiaAgricola_idGuardiaAgricola` int NOT NULL,
  PRIMARY KEY (`idlinterna`),
  KEY `fk_linterna_GuardiaAgricola1_idx` (`GuardiaAgricola_idGuardiaAgricola`),
  CONSTRAINT `fk_linterna_GuardiaAgricola1` FOREIGN KEY (`GuardiaAgricola_idGuardiaAgricola`) REFERENCES `guardiaagricola` (`idGuardiaAgricola`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linterna`
--

LOCK TABLES `linterna` WRITE;
/*!40000 ALTER TABLE `linterna` DISABLE KEYS */;
INSERT INTO `linterna` VALUES (1,_binary '\0',1235984,2);
/*!40000 ALTER TABLE `linterna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `luminosidad`
--

DROP TABLE IF EXISTS `luminosidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `luminosidad` (
  `idluminosidad` int NOT NULL AUTO_INCREMENT,
  `value` float DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `accuracy` int DEFAULT NULL,
  `GuardiaAgricola_idGuardiaAgricola` int NOT NULL,
  PRIMARY KEY (`idluminosidad`),
  KEY `fk_luminosidad_GuardiaAgricola1_idx` (`GuardiaAgricola_idGuardiaAgricola`),
  CONSTRAINT `fk_luminosidad_GuardiaAgricola1` FOREIGN KEY (`GuardiaAgricola_idGuardiaAgricola`) REFERENCES `guardiaagricola` (`idGuardiaAgricola`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `luminosidad`
--

LOCK TABLES `luminosidad` WRITE;
/*!40000 ALTER TABLE `luminosidad` DISABLE KEYS */;
/*!40000 ALTER TABLE `luminosidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimiento`
--

DROP TABLE IF EXISTS `movimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimiento` (
  `idmovimiento` int NOT NULL AUTO_INCREMENT,
  `value` bit(1) DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `accuracy` int DEFAULT NULL,
  `GuardiaAgricola_idGuardiaAgricola` int NOT NULL,
  PRIMARY KEY (`idmovimiento`),
  KEY `fk_intruso_GuardiaAgricola1_idx` (`GuardiaAgricola_idGuardiaAgricola`),
  CONSTRAINT `fk_intruso_GuardiaAgricola1` FOREIGN KEY (`GuardiaAgricola_idGuardiaAgricola`) REFERENCES `guardiaagricola` (`idGuardiaAgricola`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimiento`
--

LOCK TABLES `movimiento` WRITE;
/*!40000 ALTER TABLE `movimiento` DISABLE KEYS */;
INSERT INTO `movimiento` VALUES (1,_binary '',123456,90,2);
/*!40000 ALTER TABLE `movimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sistema_de_riego`
--

DROP TABLE IF EXISTS `sistema_de_riego`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sistema_de_riego` (
  `idSistema_de_riego` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `timestamp` bigint NOT NULL,
  `sector` varchar(45) DEFAULT NULL,
  `activo` binary(1) DEFAULT NULL,
  `GuardiaAgricola_idGuardiaAgricola` int NOT NULL,
  PRIMARY KEY (`idSistema_de_riego`),
  KEY `fk_Sistema_de_riego_GuardiaAgricola1_idx` (`GuardiaAgricola_idGuardiaAgricola`),
  CONSTRAINT `fk_Sistema_de_riego_GuardiaAgricola1` FOREIGN KEY (`GuardiaAgricola_idGuardiaAgricola`) REFERENCES `guardiaagricola` (`idGuardiaAgricola`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sistema_de_riego`
--

LOCK TABLES `sistema_de_riego` WRITE;
/*!40000 ALTER TABLE `sistema_de_riego` DISABLE KEYS */;
/*!40000 ALTER TABLE `sistema_de_riego` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temperatura`
--

DROP TABLE IF EXISTS `temperatura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temperatura` (
  `idtemperatura` int NOT NULL AUTO_INCREMENT,
  `value` float DEFAULT NULL,
  `timestamp` bigint DEFAULT NULL,
  `accuracy` int DEFAULT NULL,
  `GuardiaAgricola_idGuardiaAgricola` int NOT NULL,
  PRIMARY KEY (`idtemperatura`),
  KEY `fk_temperatura_GuardiaAgricola1_idx` (`GuardiaAgricola_idGuardiaAgricola`),
  CONSTRAINT `fk_temperatura_GuardiaAgricola1` FOREIGN KEY (`GuardiaAgricola_idGuardiaAgricola`) REFERENCES `guardiaagricola` (`idGuardiaAgricola`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temperatura`
--

LOCK TABLES `temperatura` WRITE;
/*!40000 ALTER TABLE `temperatura` DISABLE KEYS */;
INSERT INTO `temperatura` VALUES (6,20,12312,90,2),(7,18,123556444,29,2);
/*!40000 ALTER TABLE `temperatura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `idUsuario` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `dni` varchar(9) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `telefono` int DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (2,'Miguel','12412','Zapiñon',924856317,'Alicante','nene');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_has_guardiaagricola`
--

DROP TABLE IF EXISTS `usuario_has_guardiaagricola`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_has_guardiaagricola` (
  `Usuario_idUsuario` int NOT NULL,
  `GuardiaAgricola_idGuardiaAgricola` int NOT NULL,
  PRIMARY KEY (`Usuario_idUsuario`,`GuardiaAgricola_idGuardiaAgricola`),
  KEY `fk_Usuario_has_GuardiaAgricola_GuardiaAgricola1_idx` (`GuardiaAgricola_idGuardiaAgricola`),
  KEY `fk_Usuario_has_GuardiaAgricola_Usuario1_idx` (`Usuario_idUsuario`),
  CONSTRAINT `fk_Usuario_has_GuardiaAgricola_GuardiaAgricola1` FOREIGN KEY (`GuardiaAgricola_idGuardiaAgricola`) REFERENCES `guardiaagricola` (`idGuardiaAgricola`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Usuario_has_GuardiaAgricola_Usuario1` FOREIGN KEY (`Usuario_idUsuario`) REFERENCES `usuario` (`idUsuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_has_guardiaagricola`
--

LOCK TABLES `usuario_has_guardiaagricola` WRITE;
/*!40000 ALTER TABLE `usuario_has_guardiaagricola` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_has_guardiaagricola` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-17 19:38:41
